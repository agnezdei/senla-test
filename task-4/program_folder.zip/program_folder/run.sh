#!/bin/bash
echo "Запуск программы Отель..."
java -jar program.jar